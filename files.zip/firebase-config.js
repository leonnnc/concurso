// ═══════════════════════════════════════════════════════
//  firebase-config.js — Configuración Firebase
//  ⚠️  REEMPLAZA los valores con los de tu proyecto Firebase
// ═══════════════════════════════════════════════════════

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

// ─── TU CONFIGURACIÓN DE FIREBASE ───────────────────────
// Reemplaza estos valores con los de tu proyecto en:
// Firebase Console → Configuración del proyecto → SDK de configuración
const firebaseConfig = {
  apiKey:            "TU_API_KEY",
  authDomain:        "TU_PROJECT_ID.firebaseapp.com",
  projectId:         "TU_PROJECT_ID",
  storageBucket:     "TU_PROJECT_ID.appspot.com",
  messagingSenderId: "TU_MESSAGING_SENDER_ID",
  appId:             "TU_APP_ID"
};
// ────────────────────────────────────────────────────────

const app     = initializeApp(firebaseConfig);
const auth    = getAuth(app);
const db      = getFirestore(app);
const storage = getStorage(app);

// Exportar para uso en otros módulos
window.__firebase = { auth, db, storage };

export { auth, db, storage };
